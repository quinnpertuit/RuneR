# runescapeR

This package's goal is to query data directly from Runescape's Grand Exchange Auction House.

The Grand Exchange data can be a very interesting source of real data to try on forecasting methods.

It is real people buying real virtual goods.

By the end of summer/2019 this package will be up on Cran.
